from django.shortcuts import render, redirect
from .models import League, Team, Player
from django.db.models import Count

from . import team_maker

def index(request):

	#Sports ORM (part 1):
	# context = {
	# 	"leagues": League.objects.all(),
	# 	"teams": Team.objects.all(),
	# 	"players": Player.objects.all(),
	# 	"baseball_leagues": League.objects.filter(sport = 'Baseball'),
	# 	"women_leagues": League.objects.filter(name__contains="Women"),
	# 	"any_hockey_leagues": League.objects.filter(sport__contains="hockey"),
	# 	"non_football_leagues": League.objects.exclude(sport = "Football"),
	# 	"conference_leagues": League.objects.filter(name__contains= "conference"),
	# 	"atlantic_leagues": League.objects.filter(name__contains="Atlantic"),
	# 	"dallas_teams": Team.objects.filter(location = "Dallas"),
	# 	"raptors_teams": Team.objects.filter(team_name = "Raptors"),
	# 	"city_teams": Team.objects.filter(location__contains="city"),
	# 	"t_teams": Team.objects.filter(team_name__startswith="T"),
	# 	"location_ordered_teams": Team.objects.order_by('location'),
	# 	"reverse_order_name_teams": Team.objects.order_by('-team_name'),
	# 	"cooper_players": Player.objects.filter(last_name="Cooper"),
	# 	"joshua_players": Player.objects.filter(first_name="Joshua"),
	# 	"cooper_not_joshua_players":Player.objects.filter(last_name="Cooper").exclude(first_name="Joshua"),
	# 	"joshua__wyatt_players": (Player.objects.filter(first_name="Joshua")) | (Player.objects.filter(first_name="Wyatt"))
	# }

	#Sports ORM II:
	context = {
		"atlantic_soccer_conference": Team.objects.filter(league__name="Atlantic Soccer Conference"),
		"boston_penguins_players": Player.objects.filter(curr_team__location = "Boston").filter(curr_team__team_name="Penguins"),
		"icbc_players": Player.objects.filter(curr_team__league__name = "International Collegiate Baseball Conference"),
		"lopez_acaf_players": Player.objects.filter(curr_team__league__name = "American Conference of Amateur Football").filter(last_name="Lopez"),
		"all_football_players": Player.objects.filter(curr_team__league__sport="Football"),
		"sophia_teams": Team.objects.filter(curr_players__first_name="Sophia"),
		"sophia_leagues": League.objects.filter(teams__curr_players__first_name="Sophia"),
		"flores_not_roughriders_players": Player.objects.filter(last_name="Flores").exclude(curr_team__team_name="Roughriders").exclude(curr_team__location="Washington"),
		"samuel_evans_teams": Team.objects.filter(all_players__first_name="Samuel").filter(all_players__last_name="Evans"),
		"tigercats_players": Player.objects.filter(all_teams__location="Manitoba").filter(all_teams__team_name="Tiger-Cats"),
		"former_vikings_players": Player.objects.filter(all_teams__location="Wichita").filter(all_teams__team_name="Vikings").exclude(curr_team__team_name="Vikings"),
		"jacob_gray_former_teams": Team.objects.filter(all_players__last_name="Gray").filter(all_players__first_name="Jacob").exclude(curr_players__first_name="Jacob"),
		"joshua_afab_players": Player.objects.filter(first_name="Joshua").filter(all_teams__league__name="Atlantic Federation of Amateur Baseball Players"),
		"teams": Team.objects.all().annotate(Count("all_players")),
		"12_player_teams": Team.objects.annotate(num_players=Count("all_players"))
	}
	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")